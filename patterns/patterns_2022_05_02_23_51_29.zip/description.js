const GAME_DESCRIPTION = `\
<b>Patterns</b>
<p>A game about pattern matching tiles. Click a tile to select it, then select another with a matching feature. Selecting two tiles with one or more matching features will remove those features from the tile. If all features are removed from a tile by matching, any tile can be picked next without ending the streak.</p>\
`;